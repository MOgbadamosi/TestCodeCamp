public class Main {

    public static void main(String[] args) {
        System.out.println("Hello world!.This is Mariam's first pseudocode");
        System.out.println("Let's see if this will work without the quotes");
        System.out.println(30);
        System.out.println("ohhh yeah! it did work");
        System.out.println("I seem to be getting a hang of this");
        System.out.println("observation, commands seem to be case sensitive");
        System.out.println("Rayyan says i should write his name, he wants to see it appear");
    }
}